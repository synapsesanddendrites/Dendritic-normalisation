% function[connectivity,exp_forest,inh_forest,,data_out,inputs_out]=forest_learn(connectivity,exp_forest,inh_forest,forest_params,seq_params)
% if (nargin<5)||isempty(seq_params)
%     % Excitatory parameters
    seq_params.n_epochs=5; % Number of epochs
    seq_params.length_prerun=10; % Number of arbitrary repetitions per epoch to equilibriate system
    seq_params.length_run=1000; % Number of arbitrary repitions per epoch to train
    seq_params.letter_size=5; % Number of excitatory neurons receiving each input
% end
n_epochs=seq_params.n_epochs;
length_run=seq_params.length_run;
length_prerun=seq_params.length_prerun;
n_cent=seq_params.n_cent;
letter_size=seq_params.letter_size;

% Assign inputs
n_exp=length(exp_forest);
seq_inputs=cell(2,1);
all_seq_inputs=datasample(1:n_exp,6*letter_size,'Replace',false);
for bear=1:2
    for sooth=1:3
        seq_inputs{bear}{sooth}=all_seq_inputs((((bear-1)*3*letter_size+((sooth-1)*letter_size))+1):(((bear-1)*3*letter_size+((sooth-1)*letter_size))+letter_size));
    end
end

data_out=cell(n_epochs,1);
for epoch=1:n_epochs
    tic;
    new_state.exp_in=zeros(n_exp,1);
    new_state.inh_in=zeros(length(inh_forest),1);
    spike_mat=zeros(length(exp_forest),(length_run+length_prerun)*(2+n_cent));
    inh_mat=zeros(length(inh_forest),(length_run+length_prerun)*(2+n_cent));
    ind=1;
    for stim_rep=1:length_prerun
       check_val=rand(1);
       if check_val<=0.5
           next_word=1;
       else
           next_word=2;
       end
       network_state=new_state;
       network_state.exp_in(seq_inputs{next_word}{1})=1; % First letter
       spike_mat(:,ind)=network_state.exp_in;
       inh_mat(:,ind)=network_state.inh_in;
       ind=ind+1;
       new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
       for cent_ind=1:n_cent % Central part of each word
           network_state=new_state;
           network_state.exp_in(seq_inputs{next_word}{2})=1;
           spike_mat(:,ind)=network_state.exp_in;
           inh_mat(:,ind)=network_state.inh_in;
           ind=ind+1;
           new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
       end
       network_state=new_state;
       spike_mat(:,ind)=network_state.exp_in;
       inh_mat(:,ind)=network_state.inh_in;
       ind=ind+1;
       network_state.exp_in(seq_inputs{next_word}{3})=1; % Final letter
       new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
    end
    % Do training bit
    for stim_rep=1:length_run
       check_val=rand(1);
       if check_val<=0.5
           next_word=1;
       else
           next_word=2;
       end
       network_state=new_state;
       network_state.exp_in(seq_inputs{next_word}{1})=1; % First letter
       spike_mat(:,ind)=network_state.exp_in;
       inh_mat(:,ind)=network_state.inh_in;
       ind=ind+1;
       new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
       connectivity=apply_plasticity(new_state,network_state,connectivity,exp_forest); % Update weights
       for cent_ind=1:n_cent % Central part of each word
           network_state=new_state;
           network_state.exp_in(seq_inputs{next_word}{2})=1;
           spike_mat(:,ind)=network_state.exp_in;
           inh_mat(:,ind)=network_state.inh_in;
           ind=ind+1;
           new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
           connectivity=apply_plasticity(new_state,network_state,connectivity,exp_forest); % Update weights
       end
       network_state=new_state;
       spike_mat(:,ind)=network_state.exp_in;
       inh_mat(:,ind)=network_state.inh_in;
       ind=ind+1;
       network_state.exp_in(seq_inputs{next_word}{3})=1; % Final letter
       new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
       connectivity=apply_plasticity(new_state,network_state,connectivity,exp_forest); % Update weights
    end
    rate=nnz(spike_mat)/(length(exp_forest)*(2+n_cent)*(length_run+length_prerun));% Spiking rate
    t_out=toc;
    [epoch rate toc]
    [connectivity,exp_forest] = connec_SET(exp_forest,connectivity,forest_params); % Do evolutionary update
    this_struct.exp_raster=spike_mat;
    this_struct.inh_raster=inh_mat;
    this_struct.conns=connectivity;
    this_struct.forest=exp_forest;
    data_out{epoch}=this_struct;
    
inputs_out.n_cent=n_cent;
inputs_out.seq_inputs=seq_inputs;
end


%end