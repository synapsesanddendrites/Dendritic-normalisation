function [connectivity,exp_forest,inh_forest] = points_connec_init(exp_forest,inh_forest,conn_params)

if (nargin<4)||isempty(conn_params)
    EE_sparsity=0.3;
    EI_sparsity=0.3;
    IE_sparsity=0.7;
    
    EE_delt=0.15;
else
    EE_sparsity=conn_params.EE_sparsity;
    EI_sparsity=conn_params.EI_sparsity;
    IE_sparsity=conn_params.IE_sparsity;
    EE_delt=conn_params.EE_delt;
end

% Get initial connectivity matrices
EE_mat=zeros(length(exp_forest)); % Recurrent connectivity
EE_inds=datasample(1:(length(exp_forest)^2),round(EE_sparsity*(length(exp_forest)^2)),'Replace',false); % Get allowed indices
EE_vals=gamrnd(0.2,1,round(EE_sparsity*(length(exp_forest)^2)),1);
EE_mat(EE_inds)=EE_vals;

EI_mat=zeros(length(exp_forest),length(inh_forest)); % Excitatory to inhibitory connectivity
EI_inds=datasample(1:(length(exp_forest)*length(inh_forest)),round(EI_sparsity*(length(exp_forest)*length(inh_forest))),'Replace',false); % Get allowed indices
EI_vals=gamrnd(0.2,1,round(EI_sparsity*(length(exp_forest)*length(inh_forest))),1);
EI_mat(EI_inds)=EI_vals;

IE_mat=zeros(length(inh_forest),length(exp_forest)); % Inhibitory to excitatory connectivity
IE_inds=datasample(1:(length(inh_forest)*length(exp_forest)),round(IE_sparsity*(length(exp_forest)*length(inh_forest))),'Replace',false); % Get allowed indices
IE_vals=-gamrnd(0.2,1,round(IE_sparsity*(length(exp_forest)*length(inh_forest))),1);
IE_mat(IE_inds)=IE_vals;

% Place synapses on dendrites
EE_locs=zeros(length(exp_forest)); % Recurrent connectivity
EI_locs=zeros(length(exp_forest),length(inh_forest)); % Excitatory to inhibitory connectivity
IE_locs=zeros(length(inh_forest),length(exp_forest)); % Inhibitory to excitatory connectivity
% EE and IE contacts
for ward=1:length(exp_forest)
    conts=find(EE_mat(:,ward));
    aff_locs=datasample(1:length(exp_forest{ward}.X),length(conts),'Replace',true);
    EE_locs(conts,ward)=aff_locs;
    
    conts=find(IE_mat(:,ward));
    aff_locs=datasample(1:length(exp_forest{ward}.X),length(conts),'Replace',true);
    IE_locs(conts,ward)=aff_locs;
end
for ward=1:length(inh_forest)
    conts=find(EI_mat(:,ward));
    aff_locs=datasample(1:length(inh_forest{ward}.X),length(conts),'Replace',true);
    EI_locs(conts,ward)=aff_locs;
end
% Sort outputs
connectivity.EE_mat=EE_mat;
connectivity.EI_mat=EI_mat;
connectivity.IE_mat=IE_mat;
connectivity.EE_locs=EE_locs;
connectivity.EI_locs=EI_locs;
connectivity.IE_locs=IE_locs;

connectivity.threshold_exp=15;
connectivity.threshold_inh=15;
connectivity.LR=0.01;
connectivity.decay=0;

connectivity.EE_sparsity=EE_sparsity;
connectivity.EI_sparsity=EI_sparsity;
connectivity.IE_sparsity=IE_sparsity;
connectivity.eps=EE_delt;


end