% clear
% index=1;
% all_data=cell(1);
n_cents=[1,2,4,8,16];
all_data=cell(5,5);
for exclusive_ind_1=1:5
    for exclusive_ind_2=1:5
        [exp_forest,inh_forest,forest_params] = forest_init(100,25);
        [connectivity,exp_forest,inh_forest] = connec_init(exp_forest,inh_forest,forest_params);
        connectivity=threshold_tune(0.1,connectivity,exp_forest,inh_forest);
        
        seq_params.n_cent=n_cents(exclusive_ind_2); % Repetitions of central input
        forest_learn
        [vecs_out,labels_out]=forest_train(connectivity,exp_forest,inh_forest,inputs_out);
        run_data.exp_forest=exp_forest;
        run_data.inh_forest=inh_forest;
        run_data.connectivity=connectivity;
        run_data.inputs_out=inputs_out;
        run_data.vecs_out=vecs_out;
        run_data.labels_out=labels_out;
        
        X=vecs_out;
        Y=labels_out;
        Yv=value2vec(Y);
        train_pattern_recognition;
        run_data.errors=percentErrors;
        
        all_data{exclusive_ind_1,exclusive_ind_2}=run_data;
        exclusive_ind_1
        exclusive_ind_2
        save('trees_learn_3.mat','all_data')
    end
end