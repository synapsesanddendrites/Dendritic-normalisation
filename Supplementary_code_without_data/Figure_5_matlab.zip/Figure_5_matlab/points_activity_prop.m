function[out_state]=points_activity_prop(in_state,connectivity,exp_forest,inh_forest)
% Propagate activity from one timestep to the next
exp_in=in_state.exp_in;
inh_in=in_state.inh_in;

n_exp=length(exp_forest);
exp_out=zeros(n_exp,1);

p=gcp;
parfor ward=1:length(exp_forest)
    warning('off','all')
    exp_aff_locs=find(exp_in.*connectivity.EE_locs(:,ward));
    exp_aff_weights=exp_in(exp_aff_locs).*connectivity.EE_mat(exp_aff_locs,ward);
       
    inh_aff_locs=find(inh_in.*connectivity.IE_locs(:,ward));
    inh_aff_weights=inh_in(inh_aff_locs).*connectivity.IE_mat(inh_aff_locs,ward);
    
    tot_input=zeros(length(exp_forest{ward}.X),1);
    for e_ind=1:length(exp_aff_locs)
        tot_input(exp_aff_locs(e_ind))=tot_input(exp_aff_locs(e_ind))+exp_aff_weights(e_ind);
    end
    for i_ind=1:length(inh_aff_locs)
        tot_input(inh_aff_locs(i_ind))=tot_input(inh_aff_locs(i_ind))+inh_aff_weights(i_ind);
    end
    if nnz(tot_input)>0
        this_sse=sum(tot_input);
        if this_sse>=connectivity.threshold_exp
            exp_out(ward)=1;
        end
    end
end

n_inh=length(inh_forest);
inh_out=zeros(n_inh,1);
for ward=1:length(inh_forest)
    warning('off','all')
    aff_locs=find(exp_in.*connectivity.EI_locs(:,ward));
    aff_weights=exp_in(aff_locs).*connectivity.EI_mat(aff_locs,ward);
    
    tot_input=zeros(length(inh_forest{ward}.X),1);
    for i_ind=1:length(aff_locs)
        tot_input(aff_locs(i_ind))=tot_input(aff_locs(i_ind))+aff_weights(i_ind);
    end
    if nnz(tot_input)>0
        this_sse=sum(tot_input);
        if this_sse>=connectivity.threshold_inh
            inh_out(ward)=1;
        end
    end
end
out_state.exp_in=exp_out;
out_state.inh_in=inh_out;
end