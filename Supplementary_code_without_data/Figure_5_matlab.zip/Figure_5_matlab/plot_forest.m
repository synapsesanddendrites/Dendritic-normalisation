function[]=plot_forest(exp_forest,inh_forest,connectivity,with_syn)
if (nargin<4)||isempty(with_syn)
    with_syn=false;
end
figure 
hold on
exp_col_limit=[0,66/256,37/256]; % Racing green
inh_col_limit=[115/256,52/256,58/256]; % Merlot
EE_col=[212/256,165/256,32/256]; % Gold
for ward=1:length(exp_forest)
    this_col=exp_col_limit+3.8*rand(1)*exp_col_limit;
    plot_tree(exp_forest{ward},this_col);
end
for ward=1:length(inh_forest)
    this_col=inh_col_limit+2.2*rand(1)*inh_col_limit;
    plot_tree(inh_forest{ward},this_col);
end

if with_syn
    for ward=1:length(exp_forest)
        tree_inds=connectivity.EE_locs(find(connectivity.EE_locs(:,ward)),ward);
        euc_locs=[exp_forest{ward}.X(tree_inds),exp_forest{ward}.Y(tree_inds),exp_forest{ward}.Z(tree_inds)];
        scatter3(euc_locs(:,1),euc_locs(:,2),euc_locs(:,3),4,'filled','MarkerEdgeColor','none','MarkerFaceColor',EE_col)
        
        tree_inds=connectivity.IE_locs(find(connectivity.IE_locs(:,ward)),ward);
        euc_locs=[exp_forest{ward}.X(tree_inds),exp_forest{ward}.Y(tree_inds),exp_forest{ward}.Z(tree_inds)];
        scatter3(euc_locs(:,1),euc_locs(:,2),euc_locs(:,3),4,'filled','MarkerEdgeColor','none','MarkerFaceColor',inh_col_limit)
    end
    for ward=1:length(inh_forest)
        tree_inds=connectivity.EI_locs(find(connectivity.EI_locs(:,ward)),ward);
        euc_locs=[inh_forest{ward}.X(tree_inds),inh_forest{ward}.Y(tree_inds),inh_forest{ward}.Z(tree_inds)];
        scatter3(euc_locs(:,1),euc_locs(:,2),euc_locs(:,3),4,'filled','MarkerEdgeColor','none','MarkerFaceColor',exp_col_limit)
    end
    
end



end
