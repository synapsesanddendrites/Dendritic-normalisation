function[vecs_out,labels_out]=forest_train(connectivity,exp_forest,inh_forest,inputs_out,seq_params)
 if (nargin<5)||isempty(seq_params)
     % Excitatory parameters
    seq_params.length_prerun=100; % Number of arbitrary repitions per epoch to equilibriate system
    seq_params.length_run=10000; % Number of arbitrary repetitions for data
 end
length_run=seq_params.length_run;
length_prerun=seq_params.length_prerun;
seq_inputs=inputs_out.seq_inputs;
n_cent=inputs_out.n_cent;


n_exp=length(exp_forest);
vecs_out=zeros(n_exp,length_run*(2+n_cent));
labels_out=zeros(length_run*(2+n_cent),1);
new_state.exp_in=zeros(n_exp,1);
new_state.inh_in=zeros(length(inh_forest),1);
% Get network stable
for stim_rep=1:length_prerun
    check_val=rand(1);
    if check_val<=0.5
        next_word=1;
    else
        next_word=2;
    end
    network_state=new_state;
    network_state.exp_in(seq_inputs{next_word}{1})=1; % First letter
    new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
    for cent_ind=1:n_cent % Central part of each word
        network_state=new_state;
        network_state.exp_in(seq_inputs{next_word}{2})=1;
        new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
    end
    network_state=new_state;
    network_state.exp_in(seq_inputs{next_word}{3})=1; % Final letter
    new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
end
% Generate outputs
ind=1;
tic;
for stim_rep=1:length_run
    check_val=rand(1);
    if check_val<=0.5
        next_word=1;
    else
        next_word=2;
    end
    network_state=new_state;
    network_state.exp_in(seq_inputs{next_word}{1})=1; % First letter
    vecs_out(:,ind)=network_state.exp_in;
    labels_out(ind)=100*(next_word-1)+1;
    ind=ind+1;
    
    new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
    for cent_ind=1:n_cent % Central part of each word
        network_state=new_state;
        network_state.exp_in(seq_inputs{next_word}{2})=1;
        vecs_out(:,ind)=network_state.exp_in;
        labels_out(ind)=100*(next_word-1)+cent_ind+1;
        ind=ind+1;
        new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
    end
    network_state=new_state;
    vecs_out(:,ind)=network_state.exp_in;
    labels_out(ind)=100*(next_word-1)+n_cent+2;
    ind=ind+1;
    network_state.exp_in(seq_inputs{next_word}{3})=1; % Final letter
    new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
    if mod(stim_rep,100)==0
        ti=toc;
        [stim_rep/length_run ti (length_run-ti*stim_rep)/length_run]
    end
end

end


