function[connectivity]=threshold_tune(target_rate,connectivity,exp_forest,inh_forest,seq_params)
% Tunes threshold to target excitability
 if (nargin<5)||isempty(seq_params)
     % Excitatory parameters
    seq_params.n_epochs=5; % Number of epochs
    seq_params.length_run=50; % Number of arbitrary repitions per epoch
    seq_params.n_cent=5; % Repetitions of central input
    seq_params.letter_size=5; % Number of excitatory neurons receiving each input
 end
length_run=seq_params.length_run;
n_cent=seq_params.n_cent;
letter_size=seq_params.letter_size;

n_exp=length(exp_forest);
seq_inputs=cell(2,1);
for bear=1:2
    for sooth=1:3
        seq_inputs{bear}{sooth}=datasample(1:n_exp,letter_size,'Replace',false);
    end
end
no_thresh=true;
n_try=1;
while no_thresh  
    spike_mat=zeros(length(exp_forest),length_run*(2+n_cent));
    network_state.exp_in=zeros(n_exp,1);
    network_state.inh_in=zeros(length(inh_forest),1);
    ind=1;
    for stim_rep=1:length_run
       check_val=rand(1);
       if check_val<=0.5
           next_word=1;
       else
           next_word=2;
       end
       network_state.exp_in(seq_inputs{next_word}{1})=1; % First letter
       spike_mat(:,ind)=network_state.exp_in;
       ind=ind+1;
       new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
       for cent_ind=1:n_cent % Central part of each word
           network_state=new_state;
           network_state.exp_in(seq_inputs{next_word}{2})=1;
           spike_mat(:,ind)=network_state.exp_in;
           ind=ind+1;
           new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
       end
       network_state=new_state;
       spike_mat(:,ind)=network_state.exp_in;
       ind=ind+1;
       network_state.exp_in(seq_inputs{next_word}{3})=1; % Final letter
       new_state=activity_prop(network_state,connectivity,exp_forest,inh_forest); % Propagate activity
       network_state=new_state;
    end
    rate=nnz(spike_mat)/(length(exp_forest)*(2+n_cent)*length_run); % Spiking rate
    [n_try rate]
    if rate<(0.9*target_rate)
       connectivity.threshold_exp=connectivity.threshold_exp*0.75;
       connectivity.threshold_inh=connectivity.threshold_inh*1.2; 
    elseif rate>(1.1*target_rate)
       connectivity.threshold_exp=connectivity.threshold_exp*1.5;
       connectivity.threshold_inh=connectivity.threshold_inh*0.8;
    else
        no_thresh=false;
    end
    n_try=n_try+1;
end

end
