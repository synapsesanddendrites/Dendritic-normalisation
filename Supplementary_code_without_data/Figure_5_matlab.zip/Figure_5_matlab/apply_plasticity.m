function[connectivity]=apply_plasticity(new_state,old_state,connectivity,exp_forest) % Update weights
n_exp=length(exp_forest);
for new_ind=1:n_exp
    for old_ind=1:n_exp
        if new_state.exp_in(new_ind)==1 && old_state.exp_in(old_ind)==1 % Potentiate old to new and depress new to old
            % Potentiate
            if connectivity.EE_mat(old_ind,new_ind)~=0 % Only change extant connections
                %syn_loc=connectivity.EE_locs(old_ind,new_ind);
                old_weight=connectivity.EE_mat(old_ind,new_ind);
                %put_inputs=zeros(length(exp_forest{new_ind}.X),1);
                %put_inputs(syn_loc)=old_weight;
                %this_sse=sse_tree(exp_forest{new_ind},put_inputs);
                %transfer_res=this_sse(1); % Scaled transfer resistance to the soma
                
                new_weight=old_weight*(1+connectivity.LR*(connectivity.threshold_exp/5-old_weight)/connectivity.threshold_exp);
                connectivity.EE_mat(old_ind,new_ind)=new_weight;
            end
            % Depress
            if connectivity.EE_mat(new_ind,old_ind)~=0 % Only change extant connections
                %syn_loc=connectivity.EE_locs(new_ind,old_ind);
                old_weight=connectivity.EE_mat(new_ind,old_ind);
                %put_inputs=zeros(length(exp_forest{old_ind}.X),1);
                %put_inputs(syn_loc)=old_weight;
                %this_sse=sse_tree(exp_forest{old_ind},put_inputs);
                %transfer_res=this_sse(1); % Scaled transfer resistance to the soma
                
                new_weight=old_weight*(1-connectivity.LR*old_weight/connectivity.threshold_exp);
                connectivity.EE_mat(new_ind,old_ind)=new_weight;
            end
        else % Decay ineffective synapses
            % Old to new
            if connectivity.EE_mat(old_ind,new_ind)~=0 % Only change extant connections
                %syn_loc=connectivity.EE_locs(old_ind,new_ind);
                old_weight=connectivity.EE_mat(old_ind,new_ind);
               % put_inputs=zeros(length(exp_forest{new_ind}.X),1);
                %put_inputs(syn_loc)=old_weight;
               % this_sse=sse_tree(exp_forest{new_ind},put_inputs);
               % transfer_res=this_sse(1); % Scaled transfer resistance to the soma
                
                new_weight=old_weight*(1-connectivity.decay*old_weight/connectivity.threshold_exp);
                connectivity.EE_mat(old_ind,new_ind)=new_weight;
            end
            % New to old
            if connectivity.EE_mat(new_ind,old_ind)~=0 % Only change extant connections
                syn_loc=connectivity.EE_locs(new_ind,old_ind);
                old_weight=connectivity.EE_mat(new_ind,old_ind);
                %put_inputs=zeros(length(exp_forest{old_ind}.X),1);
                %put_inputs(syn_loc)=old_weight;
                %this_sse=sse_tree(exp_forest{old_ind},put_inputs);
                %transfer_res=this_sse(1); % Scaled transfer resistance to the soma
                
                new_weight=old_weight*(1-connectivity.decay*old_weight/connectivity.threshold_exp);
                connectivity.EE_mat(new_ind,old_ind)=new_weight;
            end
        end                
    end
end

end