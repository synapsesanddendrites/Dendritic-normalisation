function [out_tree] = alex_redraw_tree(in_tree,rep_len,target_syn,curr_syn,forest_params,type)
threshold=0.01; % Divergence for scaling tree
target_len=rep_len*curr_syn/target_syn;
bad_tree=1;
while bad_tree==1
    curr_len=sum(len_tree(in_tree)); % Current length
    if curr_len>target_len % Prune tree
        if abs(curr_len-target_len)>=(threshold*target_len)
            in_tree=alex_prune_node(in_tree);
        else
            in_tree=scale_tree(in_tree,target_len/curr_len);
            bad_tree=0;
        end
    elseif curr_len<target_len % Grow tree
         if abs(curr_len-target_len)>=(threshold*target_len)
            in_tree=alex_grow_node(in_tree,forest_params,type);
        else
            in_tree=scale_tree(in_tree,target_len/curr_len);
            bad_tree=0;
         end 
    else
        bad_tree=0;
    end
end
try
    out_tree=resample_tree(in_tree,5,'-');
catch
    out_tree=in_tree;
end
%out_tree=jitter_tree(out_tree,[],[],'-');
%out_tree=quaddiameter_tree(out_tree,0.2,1,'-');
%out_tree=soma_tree(out_tree,[],[],'-');

end
function[out_tree]=alex_prune_node(in_tree)
    % Prunes one node from shortest branch
    curr_len=sum(len_tree(in_tree)); % Current length
    B=find(B_tree(in_tree)); % Branchpoints
    DLs=child_tree(in_tree,len_tree(in_tree)); % Distal lengths
    n_branch=length(B);
    
    minDL=curr_len;
    if n_branch>1
        for b_ind=1:n_branch % Identify shortest branch
            if DLs(B(b_ind))<minDL
                minDL=DLs(B(b_ind));
                sht_branch=B(b_ind);
            end
        end
    else % If no other branches, just root
        sht_branch=1;
    end
    sub=sub_tree(in_tree,sht_branch); % All nodes of shortest branch
    term=T_tree(in_tree);
    to_del=sub.*term;
   out_tree=delete_tree(in_tree,find(to_del));
 end

function[out_tree]=alex_grow_node(in_tree,forest_params,type)
    % Adds another branch to shortest branch
    if type=='exp'
        X=in_tree.X(1);
        Y=in_tree.Y(1);
        Z=in_tree.Z(1);
        n_dist=0;
        while n_dist<1
            new_point=[X-forest_params.exp_tree_rad+2*forest_params.exp_tree_rad*rand(1),Y-forest_params.exp_tree_rad+2*forest_params.exp_tree_rad*rand(1),Z+forest_params.exp_tree_height*rand(1)];
            if sqrt((X-new_point(1))^2+(Y-new_point(2))^2)<=(new_point(3)*forest_params.exp_tree_rad/forest_params.exp_tree_height)
                n_dist=n_dist+1;
            end
        end
        out_tree=MST_tree({in_tree},new_point(1),new_point(2),new_point(3),forest_params.exp_bf,forest_params.exp_tree_height,[],[],'-');
    elseif type=='inh'
        X=in_tree.X(1);
        Y=in_tree.Y(1);
        Z=in_tree.Z(1);
        n_dist=0;
        while n_dist<1
            new_point=[X-forest_params.inh_tree_rad+2*forest_params.inh_tree_rad*rand(1),Y-forest_params.inh_tree_rad+2*forest_params.inh_tree_rad*rand(1),Z-forest_params.inh_tree_rad+2*forest_params.inh_tree_rad*rand(1)];
            if sqrt((X-new_point(1))^2+(Y-new_point(2))^2+(Z-new_point(3))^2)<=(forest_params.inh_tree_rad)
                n_dist=n_dist+1;
            end
        end
        out_tree=MST_tree({in_tree},new_point(1),new_point(2),new_point(3),forest_params.inh_bf,forest_params.inh_tree_rad,[],[],'-');
    end
    try
        out_tree=resample_tree(out_tree,5,'-');
    catch
        2^2;
    end
end

         