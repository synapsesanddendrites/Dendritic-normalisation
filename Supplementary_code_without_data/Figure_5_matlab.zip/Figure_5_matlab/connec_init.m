function [connectivity,exp_forest,inh_forest] = connec_init(exp_forest,inh_forest,forest_params,conn_params,show)

if (nargin<4)||isempty(conn_params)
    EE_sparsity=0.3;
    EI_sparsity=0.3;
    IE_sparsity=0.7;
    
    EE_delt=0.15;
else
    EE_sparsity=conn_params.EE_sparsity;
    EI_sparsity=conn_params.EI_sparsity;
    IE_sparsity=conn_params.IE_sparsity;
    EE_delt=conn_params.EE_delt;
end
if (nargin<5)||isempty(show)
  show=0;
end
p=gcp;
% Get initial connectivity matrices
EE_mat=zeros(length(exp_forest)); % Recurrent connectivity
EE_inds=datasample(1:(length(exp_forest)^2),round(EE_sparsity*(length(exp_forest)^2)),'Replace',false); % Get allowed indices
EE_vals=gamrnd(0.2,1,round(EE_sparsity*(length(exp_forest)^2)),1);
EE_mat(EE_inds)=EE_vals;

EI_mat=zeros(length(exp_forest),length(inh_forest)); % Excitatory to inhibitory connectivity
EI_inds=datasample(1:(length(exp_forest)*length(inh_forest)),round(EI_sparsity*(length(exp_forest)*length(inh_forest))),'Replace',false); % Get allowed indices
EI_vals=gamrnd(0.2,1,round(EI_sparsity*(length(exp_forest)*length(inh_forest))),1);
EI_mat(EI_inds)=EI_vals;

IE_mat=zeros(length(inh_forest),length(exp_forest)); % Inhibitory to excitatory connectivity
IE_inds=datasample(1:(length(inh_forest)*length(exp_forest)),round(IE_sparsity*(length(exp_forest)*length(inh_forest))),'Replace',false); % Get allowed indices
IE_vals=-gamrnd(0.2,1,round(IE_sparsity*(length(exp_forest)*length(inh_forest))),1);
IE_mat(IE_inds)=IE_vals;

% Reshape excitatory trees to match connectivity
exp_lens=zeros(length(exp_forest),1);
parfor ward=1:length(exp_forest)
    exp_lens(ward)=sum(len_tree(exp_forest{ward}));
end
mean_exp_len=mean(exp_lens); % Mean length
aff_syns_exp=zeros(length(exp_forest),1);
parfor ward=1:length(exp_forest)
    aff_syns_exp(ward)=nnz(EE_mat(:,ward))+nnz(IE_mat(:,ward));
end
mean_aff_con_exp=mean(aff_syns_exp);
parfor ward=1:length(exp_forest)
    exp_forest{ward}=alex_redraw_tree(exp_forest{ward},mean_exp_len,mean_aff_con_exp,aff_syns_exp(ward),forest_params,'exp');
    exp_forest{ward}.M=M_tree(exp_forest{ward}); % Record conductance matrices
end
% Reshape inhibitory trees to match connectivity
inh_lens=zeros(length(inh_forest),1);
parfor ward=1:length(inh_forest)
    inh_lens(ward)=sum(len_tree(inh_forest{ward}));
end
mean_inh_len=mean(inh_lens); % Mean length
aff_syns_inh=zeros(length(inh_forest),1);
parfor ward=1:length(inh_forest)
    aff_syns_inh(ward)=nnz(EI_mat(:,ward));
end
mean_aff_con_inh=mean(aff_syns_inh);
parfor ward=1:length(inh_forest)
    inh_forest{ward}=alex_redraw_tree(inh_forest{ward},mean_inh_len,mean_aff_con_inh,aff_syns_inh(ward),forest_params,'inh');
    inh_forest{ward}.M=M_tree(inh_forest{ward});
end

% Place synapses on dendrites
EE_locs=zeros(length(exp_forest)); % Recurrent connectivity
EI_locs=zeros(length(exp_forest),length(inh_forest)); % Excitatory to inhibitory connectivity
IE_locs=zeros(length(inh_forest),length(exp_forest)); % Inhibitory to excitatory connectivity
% EE and IE contacts
for ward=1:length(exp_forest)
    conts=find(EE_mat(:,ward));
    aff_locs=datasample(1:length(exp_forest{ward}.X),length(conts),'Replace',true);
    EE_locs(conts,ward)=aff_locs;
    
    conts=find(IE_mat(:,ward));
    aff_locs=datasample(1:length(exp_forest{ward}.X),length(conts),'Replace',true);
    IE_locs(conts,ward)=aff_locs;
end
for ward=1:length(inh_forest)
    conts=find(EI_mat(:,ward));
    aff_locs=datasample(1:length(inh_forest{ward}.X),length(conts),'Replace',true);
    EI_locs(conts,ward)=aff_locs;
end
% Sort outputs
connectivity.EE_mat=EE_mat;
connectivity.EI_mat=EI_mat;
connectivity.IE_mat=IE_mat;
connectivity.EE_locs=EE_locs;
connectivity.EI_locs=EI_locs;
connectivity.IE_locs=IE_locs;

connectivity.mean_exp_len=mean_exp_len;
connectivity.mean_inh_len=mean_inh_len;
connectivity.mean_aff_con_exp=mean_aff_con_exp;
connectivity.mean_aff_con_inh=mean_aff_con_inh;

connectivity.threshold_exp=15;
connectivity.threshold_inh=15;
connectivity.LR=0.01;
connectivity.decay=0;

connectivity.EE_sparsity=EE_sparsity;
connectivity.EI_sparsity=EI_sparsity;
connectivity.IE_sparsity=IE_sparsity;
connectivity.eps=EE_delt;

if show==1
    figure
    exp_col_limit=[0,66/256,37/256]; % Racing green
    inh_col_limit=[115/256,52/256,58/256]; % Merlot
    for ward=1:length(exp_forest)
        this_col=exp_col_limit+3.8*rand(1)*exp_col_limit;
        plot_tree(exp_forest{ward},this_col);
    end
    for ward=1:length(inh_forest)
        this_col=inh_col_limit+2.2*rand(1)*inh_col_limit;
        plot_tree(inh_forest{ward},this_col);
    end
end
end