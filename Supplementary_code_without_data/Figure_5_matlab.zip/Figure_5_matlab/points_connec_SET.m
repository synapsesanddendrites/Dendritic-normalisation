function[connectivity,exp_forest] = points_connec_SET(exp_forest,connectivity)

EE_mat=connectivity.EE_mat;
IE_mat=connectivity.IE_mat;


nposcon=round(connectivity.EE_sparsity*length(exp_forest)^2);
n2change=round(connectivity.eps*nposcon);
all_Evals=EE_mat(find(EE_mat));

sorted_vals=sort(all_Evals);
val_thres=sorted_vals(n2change);
EE_mat(EE_mat<=val_thres)=0; % Excise weak connections

new_inds=datasample(find(EE_mat==0),n2change,'Replace',false); % Get allowed indices
EE_vals=gamrnd(0.2,1,n2change,1);
EE_mat(new_inds)=EE_vals;

aff_syns_exp=zeros(length(exp_forest),1);

EE_locs=zeros(length(exp_forest)); % Recurrent connectivity
IE_locs=zeros(size(IE_mat)); % Excitatory to inhibitory connectivity
% EE and IE contacts
for ward=1:length(exp_forest)
    conts=find(EE_mat(:,ward));
    aff_locs=datasample(1:length(exp_forest{ward}.X),length(conts),'Replace',true);
    EE_locs(conts,ward)=aff_locs;
    
    conts=find(IE_mat(:,ward));
    aff_locs=datasample(1:length(exp_forest{ward}.X),length(conts),'Replace',true);
    IE_locs(conts,ward)=aff_locs;
end
connectivity.EE_mat=EE_mat;
connectivity.IE_mat=IE_mat;
connectivity.EE_locs=EE_locs;
connectivity.IE_locs=IE_locs;
end