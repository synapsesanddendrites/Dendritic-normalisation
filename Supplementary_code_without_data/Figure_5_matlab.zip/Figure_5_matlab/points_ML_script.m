% clear
% index=1;
% all_data=cell(1);
n_cents=[1,2,4,8,16];
points_data=cell(5,5);
for bear=1:5
    for ward=1:5
        [exp_points,inh_points,point_params] = points_init(100,25);
        [connectivity,exp_points,inh_points] = points_connec_init(exp_points,inh_points,point_params);
        connectivity=points_tune(0.1,connectivity,exp_points,inh_points);
        
        seq_params.n_cent=n_cents(ward); % Repetitions of central input
        points_learn
        [vecs_out,labels_out]=points_train(connectivity,exp_points,inh_points,inputs_out);
        run_data.exp_forest=exp_forest;
        run_data.inh_forest=inh_forest;
        run_data.connectivity=connectivity;
        run_data.inputs_out=inputs_out;
        run_data.vecs_out=vecs_out;
        run_data.labels_out=labels_out;
        
        X=vecs_out;
        Y=labels_out;
        Yv=value2vec(Y);
        train_pattern_recognition;
        run_data.errors=percentErrors;
        
        points_data{bear,ward}=run_data;
        index=index+1;
        save('pointss_learn.mat','points_data')
    end
end