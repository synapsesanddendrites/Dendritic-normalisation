function[data_out]=forest_ML()
[exp_forest,inh_forest,forest_params] = forest_init(100,25);
[connectivity,exp_forest,inh_forest] = connec_init(exp_forest,inh_forest,forest_params);
connectivity=threshold_tune(0.25,connectivity,exp_forest,inh_forest);
[connectivity,exp_forest,inh_forest,data_out]=forest_learn(connectivity,exp_forest,inh_forest,forest_params);
end