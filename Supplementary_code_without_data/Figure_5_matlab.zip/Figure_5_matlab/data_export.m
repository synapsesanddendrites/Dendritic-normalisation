function [proc_data] = data_export(all_data)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

len_ind=1;
deg_ind=1;
locw_ind=1;
somw_ind=1;
for i=1:5
    for j=1:5
        if isstruct(all_data{i,j})
            exp_forest=all_data{i,j}.exp_forest;
            connectivity=all_data{i,j}.connectivity.EE_mat;
            for k=1:100
                lengths(len_ind)=sum(len_tree(exp_forest{k}));
                len_ind=len_ind+1;
                
                degs(deg_ind)=nnz(connectivity(:,k));
                deg_ind=deg_ind+1;
            end           
            connectivity=all_data{i,j}.connectivity.EE_mat;
            for k=1:100
                for l=1:100
                    if connectivity(l,k)>0
                        locws(locw_ind)=connectivity(l,k);
                        locw_ind=locw_ind+1;
                        
                        I=zeros(length(exp_forest{k}.X),1);
                        I(all_data{i,j}.connectivity.EE_locs(l,k))=connectivity(l,k);
                        V=sse_tree(exp_forest{k},I);
                        somws(somw_ind)=V(1);
                        somw_ind=somw_ind+1;
                        
                    end
                end
            end
        end
    end
end
proc_data.lengths=lengths;
proc_data.locws=locws;
proc_data.somws=somws;
proc_data.degs=degs;

end

