function[connectivity,exp_forest] = connec_SET(exp_forest,connectivity,forest_params)

EE_mat=connectivity.EE_mat;
IE_mat=connectivity.IE_mat;


nposcon=round(connectivity.EE_sparsity*length(exp_forest)^2);
n2change=round(connectivity.eps*nposcon);
all_Evals=EE_mat(find(EE_mat));
n1=nnz(EE_mat);

sorted_vals=sort(all_Evals);
val_thres=sorted_vals(n2change);
EE_mat(EE_mat<=val_thres)=0; % Excise weak connections
n2=nnz(EE_mat);

new_inds=datasample(find(EE_mat==0),n1-n2,'Replace',false); % Get allowed indices
EE_vals=gamrnd(0.2,1,n1-n2,1);
EE_mat(new_inds)=EE_vals;

aff_syns_exp=zeros(length(exp_forest),1);
p=gcp;
parfor ward=1:length(exp_forest)
    aff_syns_exp(ward)=nnz(EE_mat(:,ward))+nnz(IE_mat(:,ward));
end

parfor ward=1:length(exp_forest)
    exp_forest{ward}=alex_redraw_tree(exp_forest{ward},connectivity.mean_exp_len,connectivity.mean_aff_con_exp,aff_syns_exp(ward),forest_params,'exp');
    exp_forest{ward}.M=M_tree(exp_forest{ward});
end

EE_locs=zeros(length(exp_forest)); % Recurrent connectivity
IE_locs=zeros(size(IE_mat)); % Excitatory to inhibitory connectivity
% EE and IE contacts
for ward=1:length(exp_forest)
    conts=find(EE_mat(:,ward));
    aff_locs=datasample(1:length(exp_forest{ward}.X),length(conts),'Replace',true);
    EE_locs(conts,ward)=aff_locs;
    
    conts=find(IE_mat(:,ward));
    aff_locs=datasample(1:length(exp_forest{ward}.X),length(conts),'Replace',true);
    IE_locs(conts,ward)=aff_locs;
end
connectivity.EE_mat=EE_mat;
connectivity.IE_mat=IE_mat;
connectivity.EE_locs=EE_locs;
connectivity.IE_locs=IE_locs;
end