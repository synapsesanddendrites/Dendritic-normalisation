function [in_data] = initial_struc()
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
in_data=cell(5,5);
for i=1:5
    for j=1:5
        [exp_forest,inh_forest,forest_params] = forest_init(100,25);
        [connectivity,exp_forest,~] = connec_init(exp_forest,inh_forest,forest_params);
        in_data{i,j}.connectivity=connectivity;
        in_data{i,j}.exp_forest=exp_forest;
    end
       
end

