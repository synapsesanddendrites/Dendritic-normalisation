function [exp_forest,inh_forest,forest_params] = forest_init(n_tree_exp,n_tree_inh,forest_params,show)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
if (nargin<3)||isempty(forest_params)
    forest_params.forest_rad=500; % Radius of column
    % Excitatory parameters
    forest_params.exp_lyr_depth=50; % Depth of excitatory somata layer
    forest_params.exp_tree_rad=125; % (Terminal) width of excitatory trees
    forest_params.exp_tree_height=350; % Height of excitatory trees
    forest_params.exp_tree_dens=50; % Number of points for exciattory trees
    forest_params.exp_bf=0.7; % Excitatory tree depth
    % Inhibitory paramters
    forest_params.inh_lyr_depth=200; % Depth of inhibitory somata layer
    forest_params.inh_lyr_loc=100; % Height above excitatory layer
    forest_params.inh_tree_rad=100; % Radius of inhibitory trees
    forest_params.inh_tree_dens=75; % Number of points for exciattory trees
    forest_params.inh_bf=0.2; % Excitatory tree depth 
end 
if (nargin<4)||isempty(show)
  show=0;
end

forest_rad=forest_params.forest_rad;
% Excitatory parameters
exp_lyr_depth=forest_params.exp_lyr_depth; % Depth of excitatory somata layer
exp_tree_rad=forest_params.exp_tree_rad; % (Terminal) width of excitatory trees
exp_tree_height=forest_params.exp_tree_height; % Height of excitatory trees
exp_tree_dens=forest_params.exp_tree_dens; % Number of points for exciattory trees
exp_bf=forest_params.exp_bf; % Excitatory tree depth
% Inhibitory paramters
inh_lyr_depth=forest_params.inh_lyr_depth; % Depth of inhibitory somata layer
inh_lyr_loc=forest_params.inh_lyr_loc; % Height above excitatory layer
inh_tree_rad=forest_params.inh_tree_rad; % Radius of inhibitory trees
inh_tree_dens=forest_params.inh_tree_dens; % Number of points for exciattory trees
inh_bf=forest_params.inh_bf; % Excitatory tree depth



% Excitatory trees
p=gcp;
exp_forest=cell(n_tree_exp,1);
parfor ward=1:n_tree_exp
    X=zeros(exp_tree_dens+1,1);
    Y=zeros(exp_tree_dens+1,1);
    Z=zeros(exp_tree_dens+1,1);
    root_ok=0;
    while root_ok==0
        tree_root=[-forest_rad+2*forest_rad*rand(1),-forest_rad+2*forest_rad*rand(1),exp_lyr_depth*rand(1)];
        if sqrt(tree_root(1)^2+tree_root(2)^2)<=forest_rad
            root_ok=1;
        end
    end
      
    X(1)=tree_root(1);
    Y(1)=tree_root(2);
    Z(1)=tree_root(3);
    n_dist=1;
    while n_dist<=exp_tree_dens
        new_point=[X(1)-exp_tree_rad+2*exp_tree_rad*rand(1),Y(1)-exp_tree_rad+2*exp_tree_rad*rand(1),Z(1)+exp_tree_height*rand(1)];
        if sqrt((X(1)-new_point(1))^2+(Y(1)-new_point(2))^2)<=(new_point(3)*exp_tree_rad/exp_tree_height)
            X(n_dist+1)=new_point(1);
            Y(n_dist+1)=new_point(2);
            Z(n_dist+1)=new_point(3);
            n_dist=n_dist+1;
        end
    end
    new_tree=MST_tree(1,X,Y,Z,exp_bf,exp_tree_height,[],[],'-');
    new_tree=resample_tree(new_tree,5,'-');
    %new_tree=jitter_tree(new_tree,[],[],'-');
    %new_tree=quaddiameter_tree(new_tree,0.2,1,'-');
    %new_tree=soma_tree(new_tree,[],[],'-');
    new_tree.D=2*ones(size(new_tree.X));
    new_tree.Ri=100;
    new_tree.Gm=5e-04;
    exp_forest{ward}=new_tree;
end


% Inhibitory trees
inh_forest=cell(n_tree_inh,1);
parfor ward=1:n_tree_inh
    X=zeros(inh_tree_dens+1,1);
    Y=zeros(inh_tree_dens+1,1);
    Z=zeros(inh_tree_dens+1,1);
    root_ok=0;
    while root_ok==0
        tree_root=[-forest_rad+2*forest_rad*rand(1),-forest_rad+2*forest_rad*rand(1),exp_lyr_depth+inh_lyr_loc+inh_lyr_depth*rand(1)];
        if sqrt(tree_root(1)^2+tree_root(2)^2)<=forest_rad
            root_ok=1;
        end
    end
      
    X(1)=tree_root(1);
    Y(1)=tree_root(2);
    Z(1)=tree_root(3);
    n_dist=1;
    while n_dist<=inh_tree_dens
        new_point=[X(1)-inh_tree_rad+2*inh_tree_rad*rand(1),Y(1)-inh_tree_rad+2*inh_tree_rad*rand(1),Z(1)-inh_tree_rad+2*inh_tree_rad*rand(1)];
        if sqrt((X(1)-new_point(1))^2+(Y(1)-new_point(2))^2+(Z(1)-new_point(3))^2)<=inh_tree_rad
            X(n_dist+1)=new_point(1);
            Y(n_dist+1)=new_point(2);
            Z(n_dist+1)=new_point(3);
            n_dist=n_dist+1;
        end
    end
    new_tree=MST_tree(1,X,Y,Z,inh_bf,inh_tree_rad,[],[],'-');
    new_tree=resample_tree(new_tree,5,'-');
   % new_tree=jitter_tree(new_tree,[],[],'-');
    %new_tree=quaddiameter_tree(new_tree,0.2,1,'-');
    %new_tree=soma_tree(new_tree,[],[],'-');
    new_tree.D=2*ones(size(new_tree.X));
    new_tree.Ri=100;
    new_tree.Gm=5e-04;
    inh_forest{ward}=new_tree;
end
if show==1
    figure
    exp_col_limit=[0,66/256,37/256]; % Racing green
    inh_col_limit=[115/256,52/256,58/256]; % Merlot
    for ward=1:n_tree_exp
        this_col=exp_col_limit+3.8*rand(1)*exp_col_limit;
        plot_tree(exp_forest{ward},this_col)
    end
    for ward=1:n_tree_inh
        this_col=inh_col_limit+2.2*rand(1)*inh_col_limit;
        plot_tree(inh_forest{ward},this_col);
    end
end
end

