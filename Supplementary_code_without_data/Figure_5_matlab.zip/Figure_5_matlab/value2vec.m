function [Y_vector] = value2vec(Y)
%VALUE2VEC Summary of this function goes here
%   Detailed explanation goes here
v=unique(Y);
len_vec=length(v);
Y_vector=zeros(len_vec,length(Y));
for i=1:length(Y)
    for j=1:len_vec
        if Y(i)==v(j)
            Y_vector(j,i)=1;
        end
    end
end


end

